## Lab Exercise 12/5/2019 Problem 1
## Author: nmessa
## Print uppercase characters

def printUpper(phrase):
    for c in phrase:
        if c.isupper():
            print (c, end = ' ')


#Test code
phrase = 'Commander Cody and the Lost Planet Airmen'
printUpper(phrase)  #C C L P A
