## Lab Exercise 12/5/2019 Problem 3
## Author: nmessa
## Print ASCII table

def printASCII():
    for i in range(256):
        print (i, '   ', chr(i))

#Test code
printASCII()  
