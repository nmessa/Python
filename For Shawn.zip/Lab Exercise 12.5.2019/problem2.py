## Lab Exercise 12/5/2019 Problem 2
## Author: nmessa
## Print digits only

def printDigits(phrase):
    for c in phrase:
        if c.isdigit():
            print (c, end = ' ')


#Test code
phrase = '1-207-363-5475'
printDigits(phrase)  #1 2 0 7 3 6 3 5 4 7 5
