## Lab Exercise 12/5/2019
## Author: nmessa
## This function will implement a Ceasar Cypher of a string

def cypher(plain, shift):
    cipherText = ""
    for c in plain:
        if c.isalpha():                         #is an alphabetic character
            if c.isupper():                     #upper case character
                ch = (ord(c)- 65 + shift) % 26  #wrap around after shift
                ch = chr(ch + 65)               #calculate encrypted character
            else:                               #lower case character
                ch = (ord(c)- 97 + shift) % 26  #wrap around after shift
                ch = chr(ch + 97)               #calculate encrypted character
        else:                                   #not an alphabetic character
            ch = c
        cipherText += str(ch)                   #add to cyphertext
    return cipherText   

#Test code
plainText = 'Hello World'
shift = 1
print (cypher(plainText, shift)) #Ifmmp Xpsme
shift = 6
print (cypher(plainText, shift)) #Nkrru Cuxrj
shift = 23
print (cypher(plainText, shift)) #Ebiil Tloia
shift = -1
print (cypher(plainText, shift)) #Gdkkn Vnqkc
plainText = 'Mayday! Mayday!'
shift = 4
print (cypher(plainText, shift))  #Qechec! Qechec!

