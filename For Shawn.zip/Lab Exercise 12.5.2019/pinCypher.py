## Lab Exercise 12/5/2019 Pin Cipher
## Author: nmessa
## This is a Julius Ceasar cipher for PIN numbers

def PINCypher(pin, shift):
    cypherText = ""
    #First try that did not work
##    for c in pin:
##        cypherText += str(chr(ord(c) + shift))
##    return cypherText

    #second try
    for c in pin:
        ch = (ord(c)-48 + shift)%10
        cypherText += str(ch)
    return cypherText   

#Test code
pin = '12345'
shift = 1
print (PINCypher(pin, shift)) #23456
shift = 6
print (PINCypher(pin, shift)) #78901
shift = 23
print (PINCypher(pin, shift)) #45678
shift = -1
print (PINCypher(pin, shift)) #01234
