## Lab Exercise 12/5/2019 Problem 4
## Author: nmessa
## Print ASCII Hour of Code

hoc = "Hour of Code"
answer = ""
for c in hoc:
    answer += str(ord(c))
    
print (answer)

##Output
##72111117114321111023267111100101
