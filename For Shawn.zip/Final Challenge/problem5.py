##Problem 5
##Author: nmessa
##Date: 1.2.2020

def maurice_wins(list1, list2):
    wins = 0
    #round 1
    if min(list1) > max(list2):
        wins += 1

    #round 2
    list1.sort()
    middle = list1[1]
    if middle > min(list2):
        wins += 1

    #round 3
    list2.sort()
    middle = list2[1]
    if max(list1) > middle:
        wins += 1

    if wins >= 2:
        return True
    else:
        return False

print(maurice_wins([3,5,10], [4,7,11]))
print(maurice_wins([6,8,9], [7,12,14]))
print(maurice_wins([1,8,20],[2,9,100]))

