##Problem 17
##Author: nmessa
##Date: 1.2.2020

def fizz_buzz(number):
    if number%5 == 0 and number%3 == 0:
        return "FizzBuzz"
    elif number%3 == 0:
        return "Fizz"
    elif number%5 == 0:
        return "Buzz"
    else:
        return number

print(fizz_buzz(3))
print(fizz_buzz(5))
print(fizz_buzz(15))
print(fizz_buzz(4))

##Output
##Fizz
##Buzz
##FizzBuzz
##4
