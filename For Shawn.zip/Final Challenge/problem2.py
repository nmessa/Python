##Problem 2
##Author: nmessa
##Date: 1.2.2020

def is_symmetrical(number):
    number = str(number)
    reverse = number[::-1]
    if number == reverse:
        return True
    else:
        return False
    

print(is_symmetrical(7227))
print(is_symmetrical(12567))
print(is_symmetrical(44444444))
print(is_symmetrical(9939))
print(is_symmetrical(1112111))

##Output
##True
##False
##True
##False
##True
