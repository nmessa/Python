##Problem 4
##Author: nmessa
##Date: 1.2.2020

def is_isogram(s):
    s = s.lower()
    letters = set()
    for ch in s:
        letters.add(ch)
    letters = list(letters)
    if len(s) == len(letters):
        return True
    else:
        return False

print(is_isogram("Algorism"))
print(is_isogram("PasSword"))
print(is_isogram("Consecutive"))

##Output
##True
##False
##False
