##Problem 9
##Author: nmessa
##Date: 1.2.2020

def letter_check(s1, s2):
    s1 = s1.lower()
    s2 = s2.lower()
    for letter in s2:
        if letter not in s1:
            return False
    return True

print(letter_check("trances", "nectar"))
print(letter_check("compadres", "DRAPES"))
print(letter_check("parses", "parsecs"))

##Output
##True
##True
##False
