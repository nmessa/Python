##Problem 6
##Author: nmessa
##Date: 1.2.2020

def is_valid_PIN(p):
    if len(p) != 4 and len(p) != 6:
        return False
    if p.isdigit():
        return True
    else:
        return False
    
print(is_valid_PIN("1234"))
print(is_valid_PIN("12345"))
print(is_valid_PIN("a234"))
print(is_valid_PIN(""))

##Output
##True
##False
##False
##False

