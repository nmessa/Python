##Problem 10
##Author: nmessa
##Date: 1.2.2020

hacker = {'a':'4', 'e':'3', 'i':'1', 'o':'0', 's':'5'}

def hacker_speak(phrase):
    phrase = phrase.lower()
    hacker_phrase = ""
    for letter in phrase:
        if letter in hacker.keys():
            hacker_phrase += hacker[letter]
        else:
            hacker_phrase += letter
    return hacker_phrase

print(hacker_speak("javascript is cool"))
print(hacker_speak("programming is fun"))
print(hacker_speak("become a coder"))

##Output
##j4v45cr1pt 15 c00l
##pr0gr4mm1ng 15 fun
##b3c0m3 4 c0d3r
