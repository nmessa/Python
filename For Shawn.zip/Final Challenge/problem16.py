##Problem 16
##Author: nmessa
##Date: 1.2.2020
from math import *

def solve_for_exp(a, b):
    x = log(b, a)
    return x

print(solve_for_exp(4,1024))
print(solve_for_exp(2,1024))
print(solve_for_exp(9,3486784401))

##Output
##5.0
##10.0
##9.999999999999998
