##Problem 7
##Author: nmessa
##Date: 1.2.2020

def total_volume(boxes):
    total = 0
    for box in boxes:
        total += (box[0] * box[1] * box[2])
    return total

print(total_volume([[4,2,4],[3,3,3],[1,1,2],[2,1,1]]))
print(total_volume([[2,2,2],[2,1,1]]))
print(total_volume([[1,1,1]]))

##Output
##63
##10
##1

