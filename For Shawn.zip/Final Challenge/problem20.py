##Problem 20
##Author: nmessa
##Date: 1.7.2020

def reverse(s):
    words = s.split()
    newString = ""
    for word in words:
        if len(word) >= 5:
            newString += word[::-1] + " "
        else:
            newString += word + " "
    return newString

print(reverse("Reverse"))
print(reverse("This is a typical sentence."))
print(reverse("The dog is big."))

##Output
##esreveR 
##This is a lacipyt .ecnetnes 
##The dog is big.
