##Problem 1
##Author: nmessa
##Date: 1.2.2020

def century(date):
    cent = date//100
    if date%100 > 0:
        cent += 1
    post = cent%10
    if post == 1 and cent < 10 or cent > 20:
        pf = "st"
    elif post == 2 and cent < 10 or cent > 20:
        pf = "nd"
    elif post == 3 and cent < 10 or cent > 20:
        pf = "rd"
    else:
        pf = "th"
    return str(cent)+ pf + " century"

print(century(1756))
print(century(1555))
print(century(1000))
print(century(1001))
print(century(2005))
print(century(205))
print(century(305))

##Output
##18th century
##16th century
##10th century
##11th century
##21st century
##3rd century
##4th century
