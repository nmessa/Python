##Problem 11
##Author: nmessa
##Date: 1.2.2020

def xmasItems(n):
    return n*(n+1)*(n+2)//6

print(xmasItems(12))
print(xmasItems(3))
print(xmasItems(31))

##Output
##364
##10
##5456
