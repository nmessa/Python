##Problem 19
##Author: nmessa
##Date: 1.7.2020

def net_present_value(pv, ir, years):
    value = pv*(1-(1+ir)**-years)/ir
    return "$" + str(int(round(value,0)))

print(net_present_value(100, 0.1, 1))
print(net_present_value(100, 0.2, 1))
print(net_present_value(100, 0.1, 20))

##Output
##$91
##$83
##$851
