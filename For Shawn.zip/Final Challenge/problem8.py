##Problem 8
##Author: nmessa
##Date: 1.2.2020

def sum_neg(lst):
    if len(lst) == 0:
        return []
    negTotal = 0
    count = 0
    for num in lst:
        if num > 0:
            count += 1
        else:
            negTotal += num
    return [count, negTotal]

print(sum_neg([1,2,3,4,5,6,7,8,9,10,-11,-12,-13,-14,-15]))
print(sum_neg([92,6,73,-77,81,-90,99,8,-85,34]))
print(sum_neg([91,-4,80,-73,-28]))
print(sum_neg([]))

##Output
##[10, -65]
##[7, -252]
##[2, -105]
##[]
