## Lab Exercise 1/8/2020 Problem 1
## Author: nmessa
## This program will find the location of a birthday
## in a million digits of Pi

#Assign filename
filename = 'pi_million_digits.txt'
#filename = 'pi-billion.txt'

#read in the lines in the file
with open(filename) as file_object:
    lines = file_object.readlines()

#build the pi string
pi_string = ''
for line in lines:
    pi_string += line.rstrip()

#Get name from user 
birthday = input("Enter your birthday (mm/dd/yyyy): ")

bd = birthday.split('/')

#Create a birthday string
myBirthday = bd[0] + bd[1] + bd[2]

###check to see if birthday is in the pi string and print it's index
if myBirthday in pi_string:
    index = pi_string.find(myBirthday)
    print("Your birthday appears in the first million digits of pi!")
    print ('At location', index)
else:
    print("Your birthday does not appear in the first million digits of pi.")
