## Lab Exercise 1/8/2020 Problem 1
## Author: nmessa
## This program will find the location of a name in the first
## billion digits of Pi

#Assign filename
##filename = 'pi_million_digits.txt'
filename = 'pi-billion.txt'

#read in the lines in the file
with open(filename) as file_object:
    lines = file_object.readlines()

#build the pi string
pi_string = ''
for line in lines:
    pi_string += line.rstrip()

#Get name from user 
name = input("Enter your name: ")

myName = ""

#Find number version of name
for letter in name:
    myName += str(ord(letter))
#print(myName)

###check to see if birthday is in the pi string and print it's index
if myName in pi_string:
    index = pi_string.find(myName)
    print("Your name appears in the first billion digits of pi!")
    print ('At location', index)
else:
    print("Your birthday does not appear in the first billion digits of pi.")
