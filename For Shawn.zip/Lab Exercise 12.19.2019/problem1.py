#Lab Exercise 12/21/2016 Problem 1
#Author: nmessa
#This program print the log base 10 of the sum of the
#characters in your name

import math

name = input("Enter your name: ")
total = 0

for c in name:
    total += ord(c)

answer = math.log10(total)

print (answer)
