##nameBase36.py
##Author: nmessa
##Date: 10.3.2019
##This program will treat all of the letters in you name
##as base 36 digits

#Get first and last name from user
first = input("Enter your first name: ")
last = input("Enter your last name: ")

#Convert first and last name to base 10 integers
firstNumber = int(first, 36)
lastNumber = int(last, 36)

#print name as base 10 integer
print(firstNumber, lastNumber)


##Output
##Enter your first name: Norman
##Enter your last name: Messa
##1245203073 33649290
